/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package beans;

import bc.TipoRespuestoFacadeLocal;
import be.TipoRespuesto;
import java.io.Serializable;
import java.util.Date;
import java.util.List;
import javax.ejb.EJB;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;

/**
 *
 * @author Daniel
 */
@ManagedBean
@SessionScoped
public class ManagedBeanTipoRepuesto implements Serializable {

    @EJB
    private TipoRespuestoFacadeLocal tipoRespuestoFacade;
    private TipoRespuesto objeto;
    private int tipo_accion = 1;

    public ManagedBeanTipoRepuesto() {
        objeto = new TipoRespuesto();
    }

    public int getTipo_accion() {
        return tipo_accion;
    }

    public void setTipo_accion(int tipo_accion) {
        this.tipo_accion = tipo_accion;
    }

    public TipoRespuesto getObjeto() {
        return objeto;
    }

    public void setObjeto(TipoRespuesto objeto) {
        this.objeto = objeto;
    }

    public List<TipoRespuesto> getLista() {
        return tipoRespuestoFacade.findAll();
    }

    public void seleccionar_item(TipoRespuesto item, int tipo_ac) {
        objeto = item;
        tipo_accion = tipo_ac;

    }

    public void reinstanciar() {
        objeto = new TipoRespuesto();
    }

    public void procesar() {
        if (tipo_accion == 1) {
            // Crear
            objeto.setFechaRegistro(new Date());
            tipoRespuestoFacade.create(objeto);
        } else if (tipo_accion == 2) {
            // Editar
            tipoRespuestoFacade.edit(objeto);
        }
         else if (tipo_accion == 3) {
            // Eliminar
            tipoRespuestoFacade.remove(objeto);
        }
    }

}
