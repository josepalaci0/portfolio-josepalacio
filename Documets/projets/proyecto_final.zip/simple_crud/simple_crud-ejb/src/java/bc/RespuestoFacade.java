/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bc;

import be.Respuesto;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

/**
 *
 * @author Daniel
 */
@Stateless
public class RespuestoFacade extends AbstractFacade<Respuesto> implements RespuestoFacadeLocal {

    @PersistenceContext(unitName = "simple_crud-ejbPU")
    private EntityManager em;

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    public RespuestoFacade() {
        super(Respuesto.class);
    }
    
}
